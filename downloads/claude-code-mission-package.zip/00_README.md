# 클로드 코드 완벽 마스터 — 미션 패키지 (2026-10-20)

인프런 「클로드 코드 완벽 마스터: AI 개발 워크플로우 기초부터 실전까지」의 **전체 미션(23개 + 추가미션) 진행 가이드와 제출물 모음**입니다.

## 구성

| 파일 | 내용 |
|------|------|
| `01_미션_속성가이드.md` | 미션별로 Claude에게 그대로 붙여 넣을 프롬프트, 사람이 할 일, 제출 형식, 실제로 겪은 함정과 해결책 |
| `02_미션_제출물_목록.md` | 24개 미션 제출 현황(상태·제출 파일), 제출 링크, 결과물 저장소·배포 주소 |
| `03_미션_제출답안.zip` | `workspace/mission` 폴더의 01~23 답안 txt·스크린샷 (제출일 정보 제외) |
| `04_프로젝트_소스/` | 미션 결과 저장소 4개의 소스 스냅샷 (`git archive`, 비밀 값 미포함) |
| `클로드코드_미션_패키지_20261020.zip` | 위 전체를 하나로 묶은 압축 파일 |

## 결과물 한눈에 보기

- 프로필 사이트 (M5·7): https://jam-bang.github.io/my-profile-site/
- Starter Kit (M10~14): https://github.com/jam-bang/nestjs-oracle-starter
- Notion 기술문서 포탈 (M15·17~20): https://notion-tech-docs-portal.vercel.app
- Supabase 이벤트 앱 Event Hub (M21~23): https://supabase-event-app.vercel.app

## 빠르게 시작하려면

`01_미션_속성가이드.md`의 **0-1. 마스터 프롬프트**를 Claude에게 붙여 넣고 미션 번호만 바꿔 진행하세요.
푸시·로그인·API 키 입력만 직접 하면 나머지는 Claude가 처리합니다.
